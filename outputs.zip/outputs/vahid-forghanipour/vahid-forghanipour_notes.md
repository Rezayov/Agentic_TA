# Teaching assistant notes

```text
TA notes — vahid-forghanipour
The derivation is largely coherent, including the walk resolvent, mass tuning, continuum kernel, and diffusive scaling. Remaining bottlenecks are the critical fixed-endpoint sum and qualifications on the continuum limit, including its normalization and coincidence point.
Final score withheld pending human review.

Questions for the student:
- Why does the zero-momentum singularity not imply divergence of the fixed-endpoint sum at criticality in four dimensions?
- At fixed nonzero separation, what happens to the unnormalized lattice propagator, and what qualification is needed at coincidence?
```
