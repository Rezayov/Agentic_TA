# Teaching assistant notes

```text
TA notes — yasaman-mahzarnia
The assessments agree on the main lattice, Fourier, convergence-threshold, and continuum-tuning derivations. Human review remains useful for fixed-endpoint convergence at criticality, path-length scaling, and the continuum propagator’s limiting and coincidence-point qualifications.
Final score withheld pending human review.

Questions for the student:
- Why can the fixed-endpoint path sum remain finite at the critical value in four dimensions?
- What path lengths contribute at finite continuum proper time, and how do they compare with shortest paths under fixed positive detuning?
- At fixed nonzero separation, what happens to the unnormalized lattice propagator as the spacing vanishes?
- Why must the pointwise continuum propagator claim exclude coincident points?
```
