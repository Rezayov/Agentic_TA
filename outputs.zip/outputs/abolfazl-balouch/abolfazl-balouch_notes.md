# Teaching assistant notes

```text
TA notes — abolfazl-balouch
The walk count, Fourier representation, and resolvent are sound. Remaining bottlenecks are the disputed small-momentum coefficient and tuning, plus omitted convergence behavior, long-path scaling, and continuum normalization and limits.
Final score withheld pending human review.

Questions for the student:
- How does the quadratic coefficient in the small-momentum expansion determine the mass-gap tuning?
- For which values of m0 does the fixed-endpoint path sum converge, including at criticality?
- Why do paths spanning fixed physical distances require diffusive length scaling, and what happens under fixed positive detuning?
- What normalization yields a finite continuum propagator, and how does the unnormalized function behave away from and at coincidence?
```
